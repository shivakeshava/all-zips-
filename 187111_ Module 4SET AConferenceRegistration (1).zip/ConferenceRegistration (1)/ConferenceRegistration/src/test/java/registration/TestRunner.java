package registration;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "C:\\Users\\bshreddy\\Desktop\\ConferenceRegistration (1)\\ConferenceRegistration\\src\\test\\java\\registrations\\conferenceregistartion.feature",glue = "registration",dryRun = false)
public class TestRunner 
{
	
}
