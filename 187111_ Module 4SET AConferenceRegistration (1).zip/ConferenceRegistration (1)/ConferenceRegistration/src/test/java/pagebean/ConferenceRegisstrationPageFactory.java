package pagebean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ConferenceRegisstrationPageFactory 
{
	WebDriver driver;
	
	//step 1 : identify elements
		@FindBy(name="txtFN")
		@CacheLookup
		WebElement firstName;
		
		
		@FindBy(xpath="//*[@id='txtLastName']")
		@CacheLookup
		WebElement lastName;
		
		@FindBy(how=How.NAME, using="Email")
		@CacheLookup
		WebElement email;
		
		@FindBy(css="input[pattern='[789][0-9]{9}']")
		@CacheLookup
		WebElement contactNo;
		
		@FindBy(how=How.NAME, using="size")
		@CacheLookup
		int personCount;
		
		@FindBy(xpath="//*[@id=\"txtAddress1\"]")
		@CacheLookup
		WebElement rooms;
		
		@FindBy(xpath="//*[@id=\"txtAddress2\"]")
		@CacheLookup
		WebElement area;

		@FindBy(how=How.NAME, using="city")
		@CacheLookup
		WebElement city;
		
		@FindBy(how=How.NAME, using="state")
		@CacheLookup
		WebElement state;
		
		@FindBy(how=How.NAME, using="memberStatus")
		@CacheLookup
		WebElement fullAccess;
		
		@FindBy(how=How.NAME, using="memberStatus")
		@CacheLookup
		WebElement nonFullAccess;
		
		
	
		@FindBy(xpath="/html/body/form/table/tbody/tr[14]/td/a")
		@CacheLookup
		WebElement nextButton;
		

		/**
		 * @return the nextButton
		 */
		public WebElement getNextButton() {
			return nextButton;
		}

		/**
		 * @param nextButton the nextButton to set
		 */
		public void setNextButton() {
			this.nextButton.click();
		}

		/**
		 * @return the driver
		 */
		public WebDriver getDriver() {
			return driver;
		}

		/**
		 * @param driver the driver to set
		 */
		public void setDriver(WebDriver driver) {
			this.driver = driver;
		}

		/**
		 * @return the firstName
		 */
		public WebElement getFirstName() {
			return firstName;
		}

		/**
		 * @param firstName the firstName to set
		 */
		public void setFirstName(String firstName) {
			this.firstName.sendKeys(firstName);
		}

		/**
		 * @return the lastName
		 */
		public WebElement getLastName() {
			return lastName;
		}

		/**
		 * @param lastName the lastName to set
		 */
		public void setLastName(String lastName) {
			this.lastName.sendKeys(lastName);
		}

		/**
		 * @return the email
		 */
		public WebElement getEmail() {
			return email;
		}

		/**
		 * @param email the email to set
		 */
		public void setEmail(String email) {
			this.email.sendKeys(email);;
		}

		/**
		 * @return the contactNo
		 */
		public WebElement getContactNo() {
			return contactNo;
		}

		/**
		 * @param contactNo the contactNo to set
		 */
		public void setContactNo(String contactNo) {
			this.contactNo.sendKeys(contactNo);;
		}

		/**
		 * @return the personCount
		 */
		public int getPersonCount() {
			return personCount;
		}

		/**
		 * @param personCount the personCount to set
		 */
		public void setPersonCount(int personCount) {
			this.personCount = personCount;
		}

		/**
		 * @return the rooms
		 */
		public WebElement getRooms() {
			return rooms;
		}

		/**
		 * @param rooms the rooms to set
		 */
		public void setRooms(String rooms) {
			this.rooms.sendKeys(rooms);;
		}

		/**
		 * @return the area
		 */
		public WebElement getArea() {
			return area;
		}

		/**
		 * @param area the area to set
		 */
		public void setArea(String area) {
			this.area.sendKeys(area);;
		}

		/**
		 * @return the city
		 */
		public WebElement getCity() {
			return city;
		}

		/**
		 * @param city the city to set
		 */
		public void setCity(String city) {
			this.city.sendKeys(city);;
		}

		/**
		 * @return the state
		 */
		public WebElement getState() {
			return state;
		}

		/**
		 * @param state the state to set
		 */
		public void setState(String state) {
			this.state.sendKeys(state);;
		}

		/**
		 * @return the fullAccess
		 */
		public WebElement getFullAccess() {
			return fullAccess;
		}

		/**
		 * @param fullAccess the fullAccess to set
		 */
		public void setFullAccess(String fullAccess) {
			this.fullAccess.sendKeys(fullAccess);;
		}

		/**
		 * @return the nonFullAccess
		 */
		public WebElement getNonFullAccess() {
			return nonFullAccess;
		}

		/**
		 * @param nonFullAccess the nonFullAccess to set
		 */
		public void setNonFullAccess(String nonFullAccess) {
			this.nonFullAccess.sendKeys(nonFullAccess);;
		}
		
		 //initiating Elements
		public ConferenceRegisstrationPageFactory(WebDriver driver) {
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}

		
		
}
