package com.fg.importOrder.importOrder.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import com.fg.importOrder.importOrder.bean.Import;

public interface ImportRepo extends JpaRepository<Import, Integer> 
{
	@Query("from Import import where import.quantity between :quantity and :quantity1")
    List <Import> findByQuantity(@Param("quantity")int quantity,@Param("quantity1") int quantity1);
	
	@Query("from Import import where import.amount > :amount")
    List <Import> findByAmount(@Param("amount")double amount);
	
}
